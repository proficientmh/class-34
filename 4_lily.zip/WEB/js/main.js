$('.submit').click(function() {
	$('.submit').css('background-color','#198754')
})
$('.submit').click(function() {
	$('.submit').html('Done!')
})

UIkit.scroll(element, options);