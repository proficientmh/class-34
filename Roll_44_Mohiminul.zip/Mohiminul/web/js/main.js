$('#accordion').accordion();
$('#tabs').tabs();

$( function() {
    var availableTags = [
      "ActionScript",
      "AppleScript",
      "Asp",
      "BASIC",
      "C",
      "C++",
      "Clojure",
      "COBOL",
      "ColdFusion",
      "Erlang",
      "Fortran",
      "Groovy",
      "Haskell",
      "Java",
      "JavaScript",
      "Lisp",
      "Perl",
      "PHP",
      "Python",
      "Ruby",
      "Scala",
      "Scheme"
    ];
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  } );


/*$('.owl-carousel').owlCarousel({
    items: 1,
    autoplay: true,
    autoplayTimeout: 1300,
    loop: true,
    nav: true,
    navText: ['Prev','Next'],
    animateOut: 'fadeOut',

$(".gallery_img a").prettyPhoto();
$(".gallery li a").prettyPhoto();
*/